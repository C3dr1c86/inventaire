"""
Application d'inventaire - Backend FastAPI
"""

__version__ = "1.0.0"
